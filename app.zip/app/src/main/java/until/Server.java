package until;

public class Server {
    public static String localhost="192.168.100.153";
    public static String Đuonganloaisp="http://" + localhost + "/banhang/getloaisp.php";
    public static String Đuongấnnphammoinhat="http://" + localhost + "/banhang/getsanpham.php";
    public static String Đuongandienthoai="http://" + localhost + "/banhang/gettheosp.php?page=";
    public static String Duongdandonhang="http://" + localhost + "/banhang/thongtinkhachhang.php";
    public static String Duongdanchitietdonhang="http://" + localhost + "/banhang/chitietdonhang.php";

}
